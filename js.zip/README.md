# ABC CO | TVET Innovate Platform

## TVET Innovation Challenge Mockup

A Vue.js-based web application showcasing three pages for the TVET Innovation Challenge in Karongi District, Rwanda.

## Folder Structure
