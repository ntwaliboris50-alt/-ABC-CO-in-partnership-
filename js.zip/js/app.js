// Vue application for TVET Innovation Platform
new Vue({
    el: '#app',
    data: {
        currentPage: 'home', // 'home', 'studentPortal', 'adminDashboard'
        // Student application form
        application: {
            projectTitle: '',
            schoolName: '',
            teamMembers: '',
            summary: '',
            link: ''
        },
        submitted: false,
        // Admin login
        adminCredentials: {
            identifier: '',
            password: ''
        },
        adminMessage: '',
        adminSuccess: false
    },
    methods: {
        // Submit student application
        submitApplication: function() {
            // Validate required fields
            if (!this.application.projectTitle.trim()) {
                alert('Please enter Project Title');
                return;
            }
            if (!this.application.schoolName.trim()) {
                alert('Please enter TVET School Name');
                return;
            }
            if (!this.application.summary.trim()) {
                alert('Please enter Project Summary / Innovation');
                return;
            }
            
            // Show success message
            this.submitted = true;
            
            // Reset form after 3 seconds
            var self = this;
            setTimeout(function() {
                self.submitted = false;
                self.application = {
                    projectTitle: '',
                    schoolName: '',
                    teamMembers: '',
                    summary: '',
                    link: ''
                };
            }, 3000);
        },
        
        // Admin login (demo mode - any credentials work)
        adminLogin: function() {
            if (!this.adminCredentials.identifier.trim()) {
                this.adminMessage = 'Please enter your ID or Email';
                this.adminSuccess = false;
                return;
            }
            
            // Demo successful login
            this.adminMessage = '✓ Login successful! Welcome to Admin Dashboard (Demo Mode)';
            this.adminSuccess = true;
            
            // Clear message and form after 3 seconds
            var self = this;
            setTimeout(function() {
                self.adminMessage = '';
                self.adminSuccess = false;
                self.adminCredentials = {
                    identifier: '',
                    password: ''
                };
            }, 3000);
        }
    }
});