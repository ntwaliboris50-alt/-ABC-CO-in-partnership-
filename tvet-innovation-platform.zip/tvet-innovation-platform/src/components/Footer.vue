<template>
  <footer class="footer">
    © ABC CO Karongi District | TVET Innovation Challenge Mockup |
  </footer>
</template>

<script setup>
</script>