<template>
  <header class="header">
    <div class="logo-section">
      <img src="/logo.png" alt="logo" class="logo">

      <div>
        <h1>ABC CO | TVET Innovate</h1>
        <p>Empowering Rwanda TVET students .karongi District</p>
      </div>
    </div>

    <nav>
      <router-link
        to="/"
        :class="{ active: activePage === 'home' }"
      >
        HOME
      </router-link>

      <router-link
        to="/student-portal"
        :class="{ active: activePage === 'student' }"
      >
        Student Portal
      </router-link>

      <router-link
        to="/admin"
        :class="{ active: activePage === 'admin' }"
      >
        Admin dashboard
      </router-link>
    </nav>
  </header>
</template>

<script setup>
defineProps({
  activePage: String
})
</script>