<template>
  <div>
    <Header activePage="admin" />

    <div class="admin-card">
      <h2>Administrator Access</h2>

      <p class="message">{{ message }}</p>

      <div class="login-row">
        <label>Student | Email</label>

        <div>
          <input
            v-model="email"
            type="text"
            placeholder="Enter your ID | Email"
          >

          <small class="error">
            {{ emailError }}
          </small>
        </div>
      </div>

      <div class="login-row">
        <label>Password</label>

        <div>
          <input
            v-model="password"
            type="password"
            placeholder="***********"
          >

          <small class="error">
            {{ passwordError }}
          </small>
        </div>
      </div>

      <button
        class="login-btn"
        @click="login"
      >
        Login as administrator
      </button>
    </div>

    <Footer />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import Header from '../components/Header.vue'
import Footer from '../components/Footer.vue'

const email = ref('')
const password = ref('')

const emailError = ref('')
const passwordError = ref('')
const message = ref('')

function login() {
  emailError.value = ''
  passwordError.value = ''
  message.value = ''

  let valid = true

  if (!email.value.trim()) {
    emailError.value = 'Email is required'
    valid = false
  } else if (
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)
  ) {
    emailError.value = 'Invalid email format'
    valid = false
  }

  if (!password.value.trim()) {
    passwordError.value = 'Password is required'
    valid = false
  } else if (password.value.length < 6) {
    passwordError.value =
      'Password must be at least 6 characters'
    valid = false
  }

  if (!valid) return

  if (
    email.value === 'admin@gmail.com' &&
    password.value === 'admin123'
  ) {
    message.value = 'Login Successful'
  } else {
    message.value = 'Invalid Email or Password'
  }
}
</script>

<style scoped>
.error {
  color: red;
  font-size: 12px;
  display: block;
  margin-top: 4px;
}

.message {
  text-align: center;
  margin-bottom: 20px;
  font-weight: bold;
}
</style>