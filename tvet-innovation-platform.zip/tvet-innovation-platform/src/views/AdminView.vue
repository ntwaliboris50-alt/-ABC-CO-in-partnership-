<template>
  <div>
    <Header activePage="admin" />

    <div class="admin-card">

      <h2>Administarator Access</h2>

      <div class="login-row">
        <label>Student | Email</label>

        <input
          type="text"
          placeholder="Enter your ID | Email"
        >
      </div>

      <div class="login-row">
        <label>Password</label>

        <input
          type="password"
          placeholder="***********"
        >
      </div>

      <button class="login-btn">
        Login as adminstrator
      </button>

    </div>

    <Footer />
  </div>
</template>

<script setup>
import Header from '../components/Header.vue'
import Footer from '../components/Footer.vue'
</script>