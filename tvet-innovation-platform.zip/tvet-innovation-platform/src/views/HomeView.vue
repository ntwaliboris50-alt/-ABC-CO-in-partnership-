
<template>
  <div>
    <Header activePage="home" />

    <div class="home-card">

      <h2>2025 Innovative Project Competition</h2>

      <p>
        ABC CO, in partnership with the Rwanda TVET Board,
        invites students from all TVET schools to submit
        breakthrough projects in green technology,
        digital transformation, and creative industries.
        The best innovations will receive funding,
        mentorship, and incubation support.
      </p>

      <div class="buttons">
        <button class="apply-btn">
          Apply as student
        </button>

        <button class="portal-btn">
          Get Student portal
        </button>
      </div>

    </div>

    <Footer />
  </div>
</template>

<script setup>
import Header from '../components/Header.vue'
import Footer from '../components/Footer.vue'
</script>