<script setup>
import { useRouter } from 'vue-router'
import Header from '../components/Header.vue'
import Footer from '../components/Footer.vue'

const router = useRouter()

function applyAsStudent() {
  router.push('/admin')
}
</script>

<template>
  <div>
    <Header activePage="home" />

    <div class="home-card">

      <h2>2025 Innovative Project Competition</h2>

      <p>
        ABC CO, in partnership with the Rwanda TVET Board,
        invites students from all TVET schools to submit
        breakthrough projects.
      </p>

      <div class="buttons">

        <button
          class="apply-btn"
          @click="applyAsStudent"
        >
          Apply as Student
        </button>

        <button
          class="portal-btn"
          @click="applyAsStudent"
        >
          Get Student Portal
        </button>

      </div>

    </div>

    <Footer />
  </div>
</template>