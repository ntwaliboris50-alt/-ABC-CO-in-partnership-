<template>
  <div>
    <Header activePage="student" />

    <div class="student-card">

      <h2>
        Submit / Update Your Project Application
      </h2>

      <form>

        <label>Project Title *</label>
        <input type="text">

        <label>TVET School Name *</label>
        <input type="text">

        <label>Team Members</label>
        <input type="text">

        <label>
          Project Summary / Innovation *
        </label>

        <textarea rows="4"></textarea>

        <label>
          Concept link (optional)
        </label>

        <input type="text">

        <button
          type="button"
          class="submit-btn"
        >
          Submit Application
        </button>

      </form>

    </div>

    <Footer />
  </div>
</template>

<script setup>
import Header from '../components/Header.vue'
import Footer from '../components/Footer.vue'
</script>