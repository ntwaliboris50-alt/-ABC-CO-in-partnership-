<template>
  <div>
    <Header activePage="student" />

    <div class="student-card">

      <h2>
        Submit / Update Your Project Application
      </h2>

      <p class="message">{{ message }}</p>

      <form @submit.prevent="submitApplication">

        <label>Project Title *</label>
        <input
          v-model="projectTitle"
          type="text"
          placeholder="Enter project title"
        >
        <small class="error">{{ titleError }}</small>

        <label>TVET School Name *</label>
        <input
          v-model="schoolName"
          type="text"
          placeholder="Enter school name"
        >
        <small class="error">{{ schoolError }}</small>

        <label>Team Members</label>
        <input
          v-model="teamMembers"
          type="text"
          placeholder="Enter team members"
        >

        <label>
          Project Summary / Innovation *
        </label>

        <textarea
          v-model="projectSummary"
          rows="4"
          placeholder="Describe your innovation"
        ></textarea>
        <small class="error">{{ summaryError }}</small>

        <label>
          Concept Link (optional)
        </label>

        <input
          v-model="conceptLink"
          type="text"
          placeholder="https://example.com"
        >

        <button
          type="submit"
          class="submit-btn"
        >
          Submit Application
        </button>

      </form>

    </div>

    <Footer />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import Header from '../components/Header.vue'
import Footer from '../components/Footer.vue'

const projectTitle = ref('')
const schoolName = ref('')
const teamMembers = ref('')
const projectSummary = ref('')
const conceptLink = ref('')

const titleError = ref('')
const schoolError = ref('')
const summaryError = ref('')
const message = ref('')

function submitApplication() {

  titleError.value = ''
  schoolError.value = ''
  summaryError.value = ''
  message.value = ''

  let valid = true

  if (!projectTitle.value.trim()) {
    titleError.value = 'Project title is required'
    valid = false
  }

  if (!schoolName.value.trim()) {
    schoolError.value = 'School name is required'
    valid = false
  }

  if (!projectSummary.value.trim()) {
    summaryError.value = 'Project summary is required'
    valid = false
  }

  if (!valid) {
    return
  }

  message.value = 'Application submitted successfully!'

  projectTitle.value = ''
  schoolName.value = ''
  teamMembers.value = ''
  projectSummary.value = ''
  conceptLink.value = ''
}
</script>

<style scoped>
.error {
  color: red;
  font-size: 12px;
  display: block;
  margin-bottom: 10px;
}

.message {
  text-align: center;
  font-weight: bold;
  margin-bottom: 15px;
  color: green;
}
</style>